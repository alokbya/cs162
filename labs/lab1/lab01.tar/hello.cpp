#include <iostream>
using namespace std;

int main()
{
	cout << "Hello from alaa.alokby1@syccuxas01!" << endl;
	return 0;
}

//array.cpp 

#include "array.h"

//put the implementations of your assigned functions here
